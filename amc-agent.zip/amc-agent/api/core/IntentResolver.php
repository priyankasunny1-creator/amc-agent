<?php

class IntentResolver
{
    public static function resolve(
        array $candidates,
        string $message
    ): array {
        $intentConfig = require __DIR__ . '/../config/intents.php';


        $msg = strtolower($message);

        if (
            str_contains($msg, 'how many') &&
            str_contains($msg, 'client') &&
            str_contains($msg, 'amc') &&
            (
                str_contains($msg, 'more than') ||
                str_contains($msg, 'above') ||
                str_contains($msg, '%')
            )
        ) {
            return [
                'intent' => 'get_clients_above_amc_usage_threshold',
                'parameters' => []
            ];
        }


        $scores = [];

        foreach ($candidates as $intent) {
            if (!isset($intentConfig[$intent])) {
                continue;
            }

            $score = 0;
            $meta = $intentConfig[$intent];

            // Prefer Tier-A
            if ($meta['tier'] === 'A') {
                $score += 3;
            }

            // Prefer intents with parameters when message is specific
            if (!empty($meta['parameters'])) {
                $score += 1;
            }

            // Lightweight keyword reinforcement (generic, not hardcoded)
            $descriptionWords = explode(' ', strtolower($meta['description']));
            foreach ($descriptionWords as $word) {
                if (strlen($word) > 4 && str_contains(strtolower($message), $word)) {
                    $score += 1;
                }
            }

            $scores[$intent] = $score;
        }

        if (empty($scores)) {
            throw new Exception('Intent missing');
        }

        arsort($scores);
        $finalIntent = array_key_first($scores);

        return [
            'intent' => $finalIntent,
            'parameters' => []
        ];
    }
}
