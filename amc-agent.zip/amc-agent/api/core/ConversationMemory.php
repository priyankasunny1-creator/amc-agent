<?php

class ConversationMemory
{
    private static function path(string $id): string
    {
        return __DIR__ . "/../storage/conversations/{$id}.json";
    }

    public static function load(string $id): array
    {
        $file = self::path($id);
        if (!file_exists($file)) {
            return [];
        }
        return json_decode(file_get_contents($file), true) ?? [];
    }

    public static function save(string $id, array $memory): void
    {
        file_put_contents(
            self::path($id),
            json_encode($memory, JSON_PRETTY_PRINT)
        );
    }

    public static function remember(
        string $id,
        string $intent,
        array $metrics,
        array $parameters = []
    ): void {
        $memory = self::load($id);

        $memory['last_intent'] = $intent;
        $memory['last_metrics'] = $metrics;
        $memory['last_parameters'] = $parameters;
        $memory['updated_at'] = date('c');

        self::save($id, $memory);
    }
}
