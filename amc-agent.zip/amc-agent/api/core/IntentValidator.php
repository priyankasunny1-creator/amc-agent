<?php

class IntentValidator
{
    public static function validate(array $intentData): void
    {
        if (!isset($intentData['intent'])) {
            throw new Exception('Intent missing');
        }

        $registry = require __DIR__ . '/../config/intents.php';

        if (!isset($registry[$intentData['intent']])) {
            throw new Exception('Unsupported intent');
        }

        $params = $intentData['parameters'] ?? [];

        foreach ($registry[$intentData['intent']]['required_params'] as $p) {
            if (!isset($params[$p])) {
                throw new Exception("Missing parameter: $p");
            }
        }
    }
}
