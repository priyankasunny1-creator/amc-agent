<?php
header('Content-Type: application/json');

// Bootstrap DB
$pdo = require __DIR__ . '/bootstrap.php';

// Core includes
require_once __DIR__ . '/core/OpenAIClient.php';
require_once __DIR__ . '/core/IntentClassifier.php';
require_once __DIR__ . '/core/IntentResolver.php';
require_once __DIR__ . '/core/IntentValidator.php';
require_once __DIR__ . '/core/SqlExecutor.php';
require_once __DIR__ . '/core/ResultNarrower.php';
require_once __DIR__ . '/core/ResponseIntelligence.php';
require_once __DIR__ . '/core/ResponseFormatter.php';
require_once __DIR__ . '/core/ConversationMemory.php';


// Input
$input = json_decode(file_get_contents('php://input'), true);
$message = trim($input['message'] ?? '');

$conversationId = $input['conversation_id'] ?? null;
$memory = $conversationId
    ? ConversationMemory::load($conversationId)
    : [];

if ($message === '') {
    echo json_encode([
        'response' => [
            'summary' => 'Please enter a query.'
        ]
    ]);
    exit;
}


try {
    /**
     * STEP 1 — Intent classification (LLM + rules)
     * returns: ['intent' => string, 'candidates' => array]
     */
    $classified = IntentClassifier::classify($message);

    if ($conversationId && !empty($memory)) {

    // Follow-up like: "what about wp clients?"
    if (
        str_contains(strtolower($message), 'what about') ||
        str_contains(strtolower($message), 'show only')
    ) {
        // Reuse last intent
        $message = $memory['last_intent'] . ' ' . $message;
    }
            }


     
    // STEP 2 — Resolve intent + parameters
    $intentData = IntentResolver::resolve(
        $classified['candidates'],
        $message
    );

    /**
     * STEP 3 — Validate intent + parameters
     */
    IntentValidator::validate($intentData);

    /**
     * STEP 4 — Execute SQL
     */
    $data = SqlExecutor::execute(
        $pdo,
        $intentData['intent'],
        $intentData['parameters'] ?? []
    );

    /**
     * STEP 5 — Narrow results
     */
    $data = ResultNarrower::narrow($data, $message);

    /**
     * STEP 6 — Intelligence layer
     */
    $intelligence = ResponseIntelligence::analyse(
        $intentData['intent'],
        $data,
        $message
    );

    if ($conversationId) {
    ConversationMemory::remember(
        $conversationId,
        $intentData['intent'],
        $intelligence['metrics'] ?? [],
        $intentData['parameters'] ?? []
    );
    }


    /**
     * STEP 7 — Final formatting
     */
    $response = ResponseFormatter::format(
        $intentData['intent'],
        $data,
        $intelligence
    );
    
    if (
    !is_array($response) ||
    !isset($response['summary']) ||
    trim($response['summary']) === ''
    ) {
        $response = [
            'summary' => 'No results available for this query. Please check the live queue at https://pm.gmi-projects.com/amc-dashboard-oauth/public/asana_fetch_queue.php'
        ];
    }


    echo json_encode([
        'intent'   => $intentData['intent'],
        'response' => $response
    ]);
    exit;

} catch (Throwable $e) {

    // Optional: log internally
    // error_log($e->getMessage());

    echo json_encode([
        'response' => [
            'summary' => 'Unable to process this request with the current data.'
        ]
    ]);
    exit;
}

