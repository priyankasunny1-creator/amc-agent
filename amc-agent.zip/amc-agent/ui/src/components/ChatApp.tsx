import { useState } from 'react';
import { ChatInput } from './ChatInput';
import { ChatWindow } from './ChatWindow';
import { ChatMessage } from '../types/ChatTypes';

export function ChatApp() {
  const [messages, setMessages] = useState<ChatMessage[]>([]);

  const sendMessage = async (text: string) => {
    const userMsg: ChatMessage = { role: 'user', content: text };
    setMessages(m => [...m, userMsg]);

    const res = await fetch('/api/index.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message: text })
    });

    const data = await res.json();

    const botMsg: ChatMessage = {
      role: 'assistant',
      content: data.response?.summary || JSON.stringify(data)
    };

    setMessages(m => [...m, botMsg]);
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100vh' }}>
      <ChatWindow messages={messages} />
      <ChatInput onSend={sendMessage} />
    </div>
  );
}