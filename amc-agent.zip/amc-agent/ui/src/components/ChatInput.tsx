import { useState } from 'react';

type Props = {
  onSend: (message: string) => void;
};

export function ChatInput({ onSend }: Props) {
  const [value, setValue] = useState('');

  const send = () => {
    if (!value.trim()) return;
    onSend(value);
    setValue('');
  };

  return (
    <div style={{ display: 'flex', gap: '8px' }}>
      <input
        value={value}
        onChange={e => setValue(e.target.value)}
        onKeyDown={e => e.key === 'Enter' && send()}
        style={{ flex: 1 }}
      />
      <button onClick={send}>Send</button>
    </div>
  );
}