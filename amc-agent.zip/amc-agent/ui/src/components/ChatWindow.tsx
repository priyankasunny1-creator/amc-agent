import { ChatMessage } from '../types/ChatTypes';

type Props = {
  messages: ChatMessage[];
};

export function ChatWindow({ messages }: Props) {
  return (
    <div style={{ padding: '12px', overflowY: 'auto', flex: 1 }}>
      {messages.map((m, i) => (
        <div key={i} style={{ marginBottom: '8px' }}>
          <strong>{m.role === 'user' ? 'You' : 'AMC'}:</strong> {m.content}
        </div>
      ))}
    </div>
  );
}